#ifndef RLANG_VECTOR_LGL_H
#define RLANG_VECTOR_LGL_H


bool r_as_bool(SEXP x);
int r_as_optional_bool(SEXP lgl);

bool r_is_true(SEXP x);


#endif
