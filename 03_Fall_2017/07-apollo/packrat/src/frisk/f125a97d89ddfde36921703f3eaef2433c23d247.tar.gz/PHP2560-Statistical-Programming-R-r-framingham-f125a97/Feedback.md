# General 

- this is a very useful tool
- there are many Framingham models my suggestion would be to code ine of the newer simpler ones


# challengea

- I think what you have is very doable. 
- formating the output to look good and be easy to interpret may be a challenge. 
- you may want to only give some of the 10 steps to patients by default then allow for additional to be displayed. 
