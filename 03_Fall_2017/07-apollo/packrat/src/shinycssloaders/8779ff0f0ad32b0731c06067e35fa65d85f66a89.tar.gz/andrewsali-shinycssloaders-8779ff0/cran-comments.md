## Re-submission comments (version upgrade from 0.1.0 to 0.2.0)

Fix bugs / add requested features that have appeared since initial CRAN submission. 

Since the package just started getting used, I would like to update the CRAN version with fixes / feature request that have been reported. I will stick to a slower update cycle with forthcoming versions.

## Test environments
* local Ubuntu 16.10 with R 3.3.3
* win-builder (development version)

## R CMD check results

There were no ERRORs or WARNINGs. 

1 NOTE: Days since last update: 3
